#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

#include "bink.h"


static void Slock( SDL_Surface *screen )
{
  if ( SDL_MUSTLOCK( screen ) )
  {
    if ( SDL_LockSurface( screen ) < 0 )
    {
      return;
    }
  }
}

static void Sulock( SDL_Surface *screen )
{
  if ( SDL_MUSTLOCK( screen ) )
  {
    SDL_UnlockSurface( screen );
  }
}


static S32 SDL_to_Bink_surface_type( SDL_Surface * screen )
{
  switch ( screen->format->BitsPerPixel )
  {
    case 16:
      return( ( ( screen->format->Gmask >> screen->format->Gshift ) > 31 ) ? 
              BINKSURFACE565 : BINKSURFACE555 );
    
    case 24:
      return( BINKSURFACE24 );

    case 32:
      return( BINKSURFACE32 );
  }

  return( -1 );
}


static void Show_next_frame( HBINK bink, SDL_Surface * screen, S32 bink_surface_type )
{
  U32 num, i;

  BinkDoFrame( bink );

  if ( !BinkShouldSkip( bink ) )
  {
    Slock( screen );

    // we use BINKNOSKIP here since we check the skip status with BinkShouldSkip above
    BinkCopyToBuffer( bink, screen->pixels, screen->pitch, 480, 0, 0, bink_surface_type | BINKNOSKIP );

    Sulock( screen );

    num = BinkGetRects( bink, BINKSURFACEFAST );
    if ( num > 0 )
    {
      SDL_Rect rects[ BINKMAXDIRTYRECTS ];
      for( i = 0 ; i < num ; i++ )
      {
        rects[ i ].x = bink->FrameRects[ i ].Left; 
        rects[ i ].y = bink->FrameRects[ i ].Top; 
        rects[ i ].w = bink->FrameRects[ i ].Width; 
        rects[ i ].h = bink->FrameRects[ i ].Height; 
      }
      SDL_UpdateRects( screen, num, rects );
    }
  }
  
  BinkNextFrame( bink );
}


int main( int argc, char *argv[] )
{
  HBINK bink;

  if ( SDL_Init( SDL_INIT_AUDIO | SDL_INIT_VIDEO ) < 0 )
  {
    printf( "Unable to init SDL: %s\n", SDL_GetError() );
    exit( 1 );
  }
  atexit( SDL_Quit );

  Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 8192 );
  
  BinkSoundUseSDLMixer();

  bink = BinkOpen( argv[ 1 ], 0 );
  if ( bink == 0 )
  {
    printf( "Unable to open file %s.\n", argv[ 1 ] );
    exit( 1 );
  }
  else
  {
    SDL_Surface * screen;
    S32 bink_surface_type;

    screen = SDL_SetVideoMode( 640, 480, 0, SDL_HWSURFACE );
    if ( screen == NULL )
    {
      printf( "Unable to set video mode: %s\n", SDL_GetError() );
      exit( 2 );
    }

    bink_surface_type = SDL_to_Bink_surface_type( screen );
    if ( bink_surface_type == -1 )
    {
      printf( "Unsupported pixel format.\n" );
      exit( 3 );
    }

    while ( 1 )
    {
      SDL_Event event;

      while ( SDL_PollEvent( &event ) )
      {
        if ( event.type == SDL_QUIT )  
          goto done;

        if ( event.type == SDL_KEYDOWN )
        {
          if ( event.key.keysym.sym == SDLK_ESCAPE )
            goto done;
        }
      }

      if ( !BinkWait( bink ) )
      {
        Show_next_frame( bink, screen, bink_surface_type );
      }
    }
  }

 done:
  BinkClose( bink );

  return( 0 );
}

// @cdep pre $DefaultsLinuxEXE
/* @cdep post
   $requiresbinary($BuildDir/binklnx.a)
   $set(LinkBins,$LinkBins -lSDL -lpthread -lSDL_mixer)
   $BuildLinuxEXE
*/
